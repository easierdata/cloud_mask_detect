# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyfmask',
 'pyfmask.detectors',
 'pyfmask.detectors.cloud',
 'pyfmask.detectors.cloud_shadow',
 'pyfmask.extractors',
 'pyfmask.extractors.auxillary_data',
 'pyfmask.extractors.metadata',
 'pyfmask.platforms',
 'pyfmask.raster_utilities']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.21.4,<2.0.0',
 'scikit-image>=0.19.1,<0.20.0',
 'scipy>=1.7.2,<2.0.0',
 'statsmodels>=0.13.1,<0.14.0']

entry_points = \
{'console_scripts': ['pyfmask = pyfmask.cli:app']}

setup_kwargs = {
    'name': 'pyfmask',
    'version': '0.1.0',
    'description': 'The definitive Python implementation of FMask 4.4 for Landsat 8 and Sentinel 2 ',
    'long_description': None,
    'author': 'mtralka',
    'author_email': 'mtralka@umd.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<3.11',
}


setup(**setup_kwargs)
