from pyfmask.cli import app


app()
